let nombre = "Luis Miguel Blanco";
let edad = "25";
let correo = "lmiguelblancoc@gmail.com";
let trabajo = "Comfenalco Santander";
let genero = "Masculino";
let hobbie = "futbol";
let altura = 1.67;
let peso = 50;
let color_pelo = "marron";
let piel = "blanca";



console.log("Mi nombre es: " +nombre);
console.log("Mi edad es: " +edad);
console.log("Mi correo electronico : " +correo);
console.log("Trabajo en : " +trabajo);
console.log("Genero : " +genero);
console.log("Hobbie : " +hobbie);
console.log("Mi altura es: " +altura);
console.log("Mi peso es: " +peso+ " Kg");
console.log("Mi color de pelo es: " +color_pelo);
console.log("Mi color de piel es: " +piel);
